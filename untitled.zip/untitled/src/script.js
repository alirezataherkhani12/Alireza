let salesLog = JSON.parse(localStorage.getItem('egg_sales_final')) || [];
let currentText = "";

// تاریخ شمسی
document.getElementById('currentDate').innerText = new Date().toLocaleDateString('fa-IR', {year:'numeric', month:'long', day:'numeric'});

const toEn = (str) => str.replace(/[۰-۹]/g, d => '۰۱۲۳۴۵۶۷۸۹'.indexOf(d));

function processInvoice() {
    const name = document.getElementById('name').value;
    const weight = parseFloat(toEn(document.getElementById('weight').value)) || 0;
    const price = parseFloat(toEn(document.getElementById('price').value)) || 0;
    const oldDebt = parseFloat(toEn(document.getElementById('oldDebt').value)) || 0;
    const paid = parseFloat(toEn(document.getElementById('paid').value)) || 0;

    if (!name || weight <= 0) { alert("نام مشتری و وزن را وارد کنید"); return; }

    const totalSale = weight * price;
    const totalBill = totalSale + oldDebt;
    const finalDebt = totalBill - paid;

    currentText = `🧾 فاکتور تخم‌مرغ\n👤 مشتری: ${name}\n⚖️ وزن: ${weight} کیلو\n💰 فی: ${price.toLocaleString()}\n💵 فروش امروز: ${totalSale.toLocaleString()}\n🔻 بدهی قبلی: ${oldDebt.toLocaleString()}\n✅ پرداختی: ${paid.toLocaleString()}\n🔴 مانده کل: ${finalDebt.toLocaleString()} تومان`;

    salesLog.push({ name, totalSale, finalDebt });
    localStorage.setItem('egg_sales_final', JSON.stringify(salesLog));

    document.getElementById('resultBox').innerText = currentText;
    document.getElementById('resultArea').classList.remove('hidden');
    
    // کپی خودکار متن
    navigator.clipboard.writeText(currentText);
    alert("فاکتور در حافظه کپی شد. حالا می‌توانید در پیامک یا واتساپ بفرستید.");

    // پاکسازی فرم
    ["weight", "price", "oldDebt", "paid"].forEach(id => document.getElementById(id).value = "");
}

function toggleReport() {
    const panel = document.getElementById('reportPanel');
    panel.style.display = (panel.style.display === 'flex') ? 'none' : 'flex';
    
    let html = "";
    let sumSale = 0, sumDebt = 0;
    salesLog.forEach(s => {
        sumSale += s.totalSale; sumDebt += s.finalDebt;
        html += `<div class="report-row"><span>${s.name}</span> <span>${s.totalSale.toLocaleString()} | مانده: ${s.finalDebt.toLocaleString()}</span></div>`;
    });
    
    document.getElementById('reportContent').innerHTML = html;
    document.getElementById('dayTotal').innerText = sumSale.toLocaleString() + " تومان";
    document.getElementById('dayDebt').innerText = sumDebt.toLocaleString() + " تومان";
}

function goToSms() { window.location.href = `sms:?body=${encodeURIComponent(currentText)}`; }
function goToWhatsapp() { window.location.href = `https://wa.me/?text=${encodeURIComponent(currentText)}`; }
function clearDaily() { if(confirm("آمار امروز صفر شود؟")) { salesLog = []; localStorage.setItem('egg_sales_final', "[]"); toggleReport(); } }
